#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
// YCRAFT coin HUD: boss bar text drawn with marker color #FAF5F0 (shadow 62,61,60)
// arrives centered with a fixed width HUD_WIDTH; move it to the right edge of the screen.
const float HUD_WIDTH = 70.0;
const float HUD_MARGIN = 4.0;
bool ycraftMarker(vec4 c) {
    ivec3 v = ivec3(round(c.rgb * 255.0));
    return v == ivec3(250, 245, 240) || v == ivec3(62, 61, 60);
}
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifdef IS_GUI
    if (ycraftMarker(Color)) {
        float yGui = (gl_Position.y / gl_Position.w - 1.0) / ProjMat[1][1];   // distance from top, GUI px
        if (yGui < 100.0) {
            gl_Position.x += (1.0 - (HUD_MARGIN + HUD_WIDTH * 0.5) * ProjMat[0][0]) * gl_Position.w;
            // boss bar rows are 19 GUI px apart: always lift the coin to the first row
            float row = floor((yGui - 1.0) / 19.0);
            gl_Position.y -= row * 19.0 * ProjMat[1][1] * gl_Position.w;
        }
    }
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
